package edu.fsu.cs.groupproject.fragments;

import android.content.Context;

public interface Communications {
    void establishCommunications(Context context);
}
