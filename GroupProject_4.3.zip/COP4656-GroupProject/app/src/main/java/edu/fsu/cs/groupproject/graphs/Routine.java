package edu.fsu.cs.groupproject.graphs;

import java.util.ArrayList;

public class Routine
{
    ArrayList<Exercise> exercises = new ArrayList<>();
    //ArrayList<int[][]> exercise = new ArrayList<>();

    //should be date March 1 2022
    String name;
    //int [][] bench_press = new int [6][2];

    Routine(String str)
    {
        name = str;
    }


}
