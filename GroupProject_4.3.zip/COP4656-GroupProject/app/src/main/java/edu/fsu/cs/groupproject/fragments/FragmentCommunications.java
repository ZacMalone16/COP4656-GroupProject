package edu.fsu.cs.groupproject.fragments;

public interface FragmentCommunications extends StartPage.StartPageCommunications
{
    // Interface used to extend the nested communication interfaces in their respective classes.
}