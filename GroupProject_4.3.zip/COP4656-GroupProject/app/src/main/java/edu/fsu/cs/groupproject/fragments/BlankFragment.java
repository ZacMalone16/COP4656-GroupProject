package edu.fsu.cs.groupproject.fragments;

import androidx.fragment.app.Fragment;

public class BlankFragment extends Fragment {
    public BlankFragment() {
    }
}
