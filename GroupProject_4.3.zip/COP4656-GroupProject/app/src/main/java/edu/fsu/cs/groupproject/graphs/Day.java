package edu.fsu.cs.groupproject.graphs;

import java.util.ArrayList;

public class Day
{
    ArrayList<Exercise> exercises = new ArrayList<>();
    String date;

    Day(String d)
    {
        date = date;
    }

}
